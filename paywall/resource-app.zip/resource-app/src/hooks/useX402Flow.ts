import { useCallback, useMemo, useRef, useState } from 'react';
import { Facilitator } from '@crypto.com/facilitator-client';
import { createApiClient } from '../integration/api';
import type { PaymentChallenge } from '../integration/api.interfaces';
import { ensureWallet } from '../utils/wallet';
import { ensureCronosChain } from '../utils/cronos';

/**
 * Options for configuring the X402 payment flow hook.
 */
export interface UseX402FlowOptions {
  /**
   * Base URL of the API server (e.g. `http://localhost:8787`).
   */
  apiBase: string;
}

/**
 * Result returned by {@link useX402Flow}.
 *
 * Responsibilities:
 * - Expose UI-friendly state for the current payment/access flow.
 * - Provide helper functions to trigger and retry the protected fetch.
 *
 * @remarks
 * - `status` is intended for display to end users.
 * - `data` is a serialized representation of the protected payload.
 */
export interface UseX402FlowResult {
  /** Human-readable status describing the current step of the flow. */
  status: string;

  /** Serialized response data from the protected endpoint. */
  data: string;

  /** Payment identifier associated with the last successful settlement. */
  paymentId: string;

  /** Fee amount in devUSDC.e base units (6 decimals). */
  feeUSDC: string;

  /** Indicates the flow is busy (requesting, paying, or waiting). */
  isBusy: boolean;

  /**
   * Requests the protected resource.
   *
   * @param existingPaymentId - Optional previously-settled payment id to reuse.
   * @returns Resolves when the request (and any required payment flow) completes.
   * @throws If an unexpected API response is encountered.
   */
  fetchSecret: (pair: string, existingPaymentId?: string, amounts?: PaymentAmounts) => Promise<void>;

  /**
   * Retries the protected request using the last known `paymentId`, if present.
   *
   * @returns Resolves when the request completes (or no-ops if `paymentId` is empty).
   */
  retryWithPaymentId: () => Promise<void>;
}

export interface PaymentAmounts {
  amountUSDC?: string;
  amountTCRO?: string;
}

/**
 * React hook implementing an X402 payment + access flow.
 *
 * Flow overview:
 * 1) Attempt to fetch the protected resource.
 * 2) If access is granted, store the returned payload.
 * 3) If a 402/X402 challenge is returned, prompt the user to sign a payment.
 * 4) POST the signed payment to `/api/pay` for verification and settlement.
 * 5) Retry the protected request using the settled payment id.
 *
 * @param options - Hook configuration options.
 * @returns State and helpers for driving the X402 flow from a UI.
 */
export function useX402Flow(options: UseX402FlowOptions): UseX402FlowResult {
  const { apiBase } = options;

  /**
   * API client memoized by base URL.
   */
  const api = useMemo(() => createApiClient({ apiBase }), [apiBase]);

  const [status, setStatus] = useState<string>('');
  const [data, setData] = useState<string>('');
  const [paymentId, setPaymentId] = useState<string>('');
  const [lastPair, setLastPair] = useState<string>('');
  const [lastAmounts, setLastAmounts] = useState<PaymentAmounts>({});
  const [feeUSDC, setFeeUSDC] = useState<string>('');
  const [isBusy, setIsBusy] = useState<boolean>(false);
  const [lastPayloadKey, setLastPayloadKey] = useState<string>('');
  const busyCount = useRef(0);

  const setBusy = (delta: number) => {
    busyCount.current += delta;
    if (busyCount.current < 0) busyCount.current = 0;
    setIsBusy(busyCount.current > 0);
  };

  const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

  const getPayloadKey = (payload: unknown): string => {
    if (!payload || typeof payload !== 'object') return '';
    const obj = payload as Record<string, unknown>;
    const keyParts = [
      obj.pair,
      obj.sedaRequestId,
      obj.relayedAt,
      obj.cronosTxHash,
      obj.fairPriceScaled,
      obj.confidenceScoreScaled,
      obj.maxSafeExecutionSizeScaled,
      obj.flags,
    ]
      .filter(Boolean)
      .map(String);
    if (keyParts.length) return keyParts.join('|');
    return JSON.stringify(obj);
  };

  /**
   * Handles an X402 payment challenge by guiding the user through wallet-based payment.
   *
   * Responsibilities:
   * - Validate the challenge payload.
   * - Ensure wallet connection and correct Cronos network.
   * - Generate and sign an EIP-3009 payment header.
   * - Submit the payment for verification and settlement.
   * - Retry the protected request on success.
   *
   * @param challenge - X402 payment challenge returned by the API.
   * @returns Resolves after attempting settlement and (if successful) re-fetching the resource.
   * @throws If the challenge payload is malformed or incomplete.
   */
  async function handlePaymentChallenge(challenge: PaymentChallenge) {
    setBusy(1);
    try {
      const accepts0 = challenge.accepts?.[0];
      if (!accepts0) throw new Error('Invalid x402 response: accepts[0] missing');

      const nextPaymentId = accepts0.extra?.paymentId;
      if (!nextPaymentId) {
        throw new Error('Invalid x402 response: accepts[0].extra.paymentId missing');
      }
      setFeeUSDC(String(accepts0.extra?.feeUSDC ?? ''));

      const provider = await ensureWallet();
      await ensureCronosChain(accepts0.network);
      const signer = await provider.getSigner();

      setStatus('Signing EIP-3009 payment header in wallet...');

      const fac = new Facilitator({ network: accepts0.network });
      const paymentHeader = await fac.generatePaymentHeader({
        to: accepts0.payTo,
        value: accepts0.maxAmountRequired,
        asset: accepts0.asset,
        signer,
        validBefore: Math.floor(Date.now() / 1000) + accepts0.maxTimeoutSeconds,
        validAfter: 0,
      });

      setStatus('Sending /api/pay (verify + settle) ...');

      const payRes = await api.postPay({
        paymentId: nextPaymentId,
        paymentHeader,
        paymentRequirements: accepts0,
        amountUSDC: lastAmounts.amountUSDC,
        amountTCRO: lastAmounts.amountTCRO,
      });

      if (payRes.kind === 'error') {
        setStatus(`Payment failed: ${JSON.stringify(payRes.data)}`);
        return;
      }

      setPaymentId(nextPaymentId);
      setStatus(`Payment settled. txHash=${payRes.data.txHash ?? '--'}`);

      await fetchSecret(lastPair, nextPaymentId, lastAmounts);
    } finally {
      setBusy(-1);
    }
  }

  /**
   * Requests the protected resource, optionally using an existing payment id.
   *
   * @param existingPaymentId - Previously-settled payment id to reuse, if available.
   * @returns Resolves when the request completes (including any required payment flow).
   * @throws If an unexpected API response is encountered.
   */
  const fetchSecret = useCallback(
    async (pair: string, existingPaymentId?: string, amounts: PaymentAmounts = {}) => {
      setBusy(1);
      try {
        if (!pair) {
          setStatus('Select a pair to continue.');
          return;
        }

        const isNewPair = pair !== lastPair;
        setLastPair(pair);
        setLastAmounts(amounts);
        if (isNewPair) {
          setData('');
          setLastPayloadKey('');
          setPaymentId('');
          setFeeUSDC('');
        }
        setStatus(`Requesting /api/data?pair=${pair} ...`);
        if (!existingPaymentId) {
          setData('');
        }

        const maxRetries = 4;
        let attempt = 0;
        while (attempt <= maxRetries) {
          const result = await api.getData(pair, existingPaymentId, amounts);

          if (result.kind === 'ok') {
            const payloadPair =
              result.data && typeof result.data === 'object'
                ? String((result.data as Record<string, unknown>).pair ?? '')
                : '';
            if (payloadPair && payloadPair !== pair && attempt < maxRetries) {
              setStatus('Waiting for consensus... (stale pair)');
              attempt += 1;
              await wait(4000);
              continue;
            }
            const payloadKey = getPayloadKey(result.data);
            if (payloadKey && payloadKey === lastPayloadKey && attempt < maxRetries) {
              setStatus('Waiting for consensus... (retrying)');
              attempt += 1;
              await wait(4000);
              continue;
            }
            setData(JSON.stringify(result.data, null, 2));
            setLastPayloadKey(payloadKey);
            setStatus('Access granted');
            break;
          }

          if (result.kind === 'payment_required') {
            setStatus(`Payment required: ${result.challenge.error ?? 'payment_required'}`);
            await handlePaymentChallenge(result.challenge);
            break;
          }

          throw new Error(`Unexpected response: ${result.status} ${result.text}`);
        }
      } finally {
        setBusy(-1);
      }
    },
    [api, handlePaymentChallenge, lastPair]
  );

  /**
   * Retries the protected request using the last successful payment id.
   *
   * @returns Resolves when the request completes (or no-ops if `paymentId` is empty).
   */
  const retryWithPaymentId = useCallback(async () => {
    if (!paymentId || !lastPair) return;
    await fetchSecret(lastPair, paymentId, lastAmounts);
  }, [paymentId, lastPair, fetchSecret, lastAmounts]);

  return { status, data, paymentId, feeUSDC, isBusy, fetchSecret, retryWithPaymentId };
}
