import styled from 'styled-components';

export const StyledStatusBar = styled.div`
  margin-bottom: 12px;
`;
