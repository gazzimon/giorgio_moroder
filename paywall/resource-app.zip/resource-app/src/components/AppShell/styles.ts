import styled from 'styled-components';

export const StyledAppShell = styled.div`
  font-family: system-ui;
  padding: 24px;
  max-width: 860px;
`;

export const StyledTitle = styled.h1``;

export const StyledDescription = styled.p``;
