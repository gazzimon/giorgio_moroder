import styled from 'styled-components';

export const StyledPaymentIdBar = styled.div`
  margin-bottom: 12px;
`;
